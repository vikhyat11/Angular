import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayallComponent } from './displayall/displayall.component';
import { AddExpenseComponent } from './add-expense/add-expense.component';
import { UpdateExpenseComponent } from './update-expense/update-expense.component';


const routes: Routes = [
  { path: '', redirectTo: 'add', pathMatch: 'full'},
  { path: 'displayall', component: DisplayallComponent},
  { path: 'add', component: AddExpenseComponent},
  { path: 'update', component: UpdateExpenseComponent}



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
